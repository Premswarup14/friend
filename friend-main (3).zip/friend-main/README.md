<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display image</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #CD5C5C;
            text-align: center;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #CD5C5C;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
        }
        img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Friends Forever</h1>
		<h1>Swarup</h1>
		<h1>Suzulu</h1>
		<h1>Puli</h1>
		<h1>Nani</h1>
		<h1>Nomu</h1>
		<h1>Prem</h1>
        <img src="src="friend/friends.jpg_to_friends.jpg" >
		<alt="Fuckers" width="300" height="200">
    </div>
</body>
</html>
